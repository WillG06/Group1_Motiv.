
function $(sel, root=document){ return root.querySelector(sel); }

$('#lang-select')?.addEventListener('change', e => {
  console.log('Language set to:', e.target.value);
});

function buildTimeOptions(selectEl, stepMinutes = 15) {
  if (!selectEl) return;
  selectEl.innerHTML = '';
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += stepMinutes) {
      const hh = String(h).padStart(2, '0');
      const mm = String(m).padStart(2, '0');
      const opt = document.createElement('option');
      opt.value = `${hh}:${mm}`;
      opt.textContent = `${hh}:${mm}`;
      selectEl.appendChild(opt);
    }
  }
}
function roundToStep(date, stepMin = 15) {
  const ms = stepMin * 60 * 1000;
  return new Date(Math.ceil(date.getTime() / ms) * ms);
}
function toLocalDateStr(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function toTimeStr(d) {
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}
function combine(dateStr, timeStr) { return new Date(`${dateStr}T${timeStr}:00`); }

const pDate = $('#pickup-date');
const pTime = $('#pickup-time');
const dDate = $('#dropoff-date');
const dTime = $('#dropoff-time');
const durationHint = $('#duration-hint');

buildTimeOptions(pTime, 15);
buildTimeOptions(dTime, 15);

(function setDefaults(){
  const nowRounded = roundToStep(new Date(Date.now() + 2*60*60*1000));
  const drop = new Date(nowRounded.getTime() + 26*60*60*1000);

  pDate.value = toLocalDateStr(nowRounded);
  pTime.value = toTimeStr(nowRounded);

  dDate.value = toLocalDateStr(drop);
  dTime.value = toTimeStr(drop);

  pDate.min = toLocalDateStr(new Date());

  enforcePickupMinTime();
  updateDurationHint();
})();

function enforcePickupMinTime(){
  const now = new Date();
  if (pDate.value === toLocalDateStr(now)) {
    const minT = toTimeStr(roundToStep(now));
    [...pTime.options].forEach(o => o.disabled = (o.value < minT));
    if (pTime.value < minT) pTime.value = minT;
  } else {
    [...pTime.options].forEach(o => o.disabled = false);
  }
}

[pDate, pTime].forEach(el => el.addEventListener('change', () => {
  enforcePickupMinTime();
  const p = getPickup();
  const minReturn = new Date(p.getTime() + 60*60*1000); 
  const d = getDropoff();
  if (d <= minReturn) {
    const rounded = roundToStep(minReturn);
    dDate.value = toLocalDateStr(rounded);
    dTime.value = toTimeStr(rounded);
  }
  updateDurationHint();
}));
[dDate, dTime].forEach(el => el.addEventListener('change', updateDurationHint));

function getPickup(){ return combine(pDate.value, pTime.value); }
function getDropoff(){ return combine(dDate.value, dTime.value); }

function updateDurationHint(){
  const p = getPickup(), d = getDropoff();
  if (isNaN(p) || isNaN(d)) { durationHint.textContent = ''; return; }
  const diffH = (d - p) / 36e5;
  if (diffH <= 0) { durationHint.textContent = 'Return must be after pickup.'; return; }
  const days = Math.floor(diffH / 24);
  const hours = Math.round(diffH % 24);
  const parts = [];
  if (days) parts.push(`${days} day${days>1?'s':''}`);
  if (hours) parts.push(`${hours} hour${hours>1?'s':''}`);
  durationHint.textContent = `Rental duration: ${parts.join(' ')}.`;
}

const featuredCars = [
  {
    id: "tesla-plaid",
    name: "Tesla Model S Plaid",
    class: "Electric • 5 seats • 1020 HP",
    price: 120, unit: "day",
    img: "ModelSPlaid.png.webp",
    alt: "Black Tesla Model S Plaid parked outside a modern building"
  },
  {
    id: "c63s-amg",
    name: "Mercedes-AMG C63S Coupe",
    class: "Petrol • 2 doors • V8 Biturbo",
    price: 110, unit: "day",
    img: "C63s.jpg",
    alt: "White Mercedes-AMG C63S parked in front of showroom"
  },
  {
    id: "bmw-m3",
    name: "BMW M3 Competition",
    class: "Performance Sedan • 5 seats",
    price: 105, unit: "day",
    img: "BMW.jpg",
    alt: "Green BMW M3 Competition parked indoors"
  }
];

const featuredWrap = $('#featured');
const resultsWrap  = $('#results');
const placeholder  = document.querySelector('.placeholder');
const form         = $('#search-form');
const btnAvailable = $('#btn-available');

function renderCards(list, intoEl) {
  intoEl.innerHTML = '';
  const tpl = document.querySelector('#car-card-tpl');
  list.forEach(item => {
    const node = tpl.content.cloneNode(true);
    const imgEl = node.querySelector("img");
    imgEl.src = item.img;
    imgEl.alt = item.alt || item.name;
    imgEl.onerror = () => { imgEl.src = 'images/placeholder-car.jpg'; };

    node.querySelector(".car-card__title").textContent = item.name;
    node.querySelector(".car-card__meta").textContent = item.class;
    node.querySelector(".car-card__price").textContent = `£${item.price} / ${item.unit}`;

    const go = () => {
      const params = new URLSearchParams(getPayload());
      window.location.href = `/cars/${encodeURIComponent(item.id)}?${params.toString()}`;
    };
    node.querySelector(".car-card").addEventListener("click", go);
    node.querySelector(".car-card__book").addEventListener("click", (e) => { e.stopPropagation(); go(); });

    intoEl.appendChild(node);
  });
}
renderCards(featuredCars, featuredWrap);

function getPayload() {
  return {
    location: $('#location').value.trim(),
    pickup: getPickup().toISOString(),
    dropoff: getDropoff().toISOString()
  };
}
function validate() {
  const now = new Date();
  const p = getPickup(), d = getDropoff();
  if (!$('#location').value.trim()) return {ok:false, msg:'Please enter a location.'};
  if (p < now) return {ok:false, msg:'Pickup time cannot be in the past.'};
  if (d <= p) return {ok:false, msg:'Return time must be after pickup time.'};
  return {ok:true};
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  btnAvailable.disabled = true;

  const v = validate();
  if (!v.ok) { alert(v.msg); btnAvailable.disabled = false; return; }

  const payload = getPayload();
  localStorage.setItem('motiv:lastSearch', JSON.stringify(payload));

  document.querySelector('.results').setAttribute('aria-busy','true');
  placeholder.classList.add('hidden');
  resultsWrap.classList.remove('hidden');
  resultsWrap.innerHTML = `<div class="card">Searching for cars in <b>${payload.location}</b>…</div>`;

  try{
    const resp = await fetch('/api/cars/search', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });

    let data;
    if (!resp.ok) {
      data = featuredCars.map(c => ({...c, price:c.price + 5}));
    } else {
      data = await resp.json();
    }

    if (!Array.isArray(data) || data.length === 0) {
      resultsWrap.innerHTML = `<div class="card">No cars available for your dates at ${payload.location}.</div>`;
    } else {
      renderCards(data, resultsWrap);
    }
  }catch(err){
    console.error(err);
    resultsWrap.innerHTML = `<div class="card">We couldn't reach the server. Showing featured cars instead.</div>`;
    renderCards(featuredCars, resultsWrap);
  }finally{
    document.querySelector('.results').setAttribute('aria-busy','false');
    btnAvailable.disabled = false;
  }
});
(function initBackgroundSlider(){
    const slides = document.querySelectorAll('.bg-slider .bg-slide');
    if (!slides.length) return;
  
    let i = 0;
    const intervalMs = 8000;
    let timer = null;
  
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
    function show(n){
      slides.forEach((img, idx) => img.classList.toggle('active', idx === n));
    }
    function start(){
      if (prefersReduced) { show(0); return; }
      stop();
      timer = setInterval(() => {
        i = (i + 1) % slides.length;
        show(i);
      }, intervalMs);
    }
    function stop(){ if (timer) { clearInterval(timer); timer = null; } }
  
    show(0);
    start();
  
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stop(); else start();
    });
  
    try{
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      mq.addEventListener?.('change', () => { stop(); start(); });
    }catch{}
  })();
  

$('#city-go').addEventListener('click', () => {
  const city = $('#uk-city').value;
  if (!city) return;
  $('#location').value = city;
  window.scrollTo({ top: 0, behavior: 'smooth' });
  setTimeout(() => $('#pickup-date')?.focus(), 250);
});

(function restore(){
  try{
    const saved = JSON.parse(localStorage.getItem('motiv:lastSearch'));
    if (!saved) return;
    $('#location').value = saved.location || '';
    const p = new Date(saved.pickup), d = new Date(saved.dropoff);
    if (!isNaN(p)) { pDate.value = toLocalDateStr(p); pTime.value = toTimeStr(p); }
    if (!isNaN(d)) { dDate.value = toLocalDateStr(d); dTime.value = toTimeStr(d); }
    updateDurationHint();
  }catch{}
})();
